/*
Shahad Alhaddad
Reem Alnasser
Sara Alzoman
Yara Alsubhi
Shooq Aldowsarri
*/
package operatingsystemproject;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;


public class OperatingSystemProject {

    
    //ta3refat
    ArrayList<PCB> q1;
    ArrayList<PCB> q1part2;///// for second time add process
    ArrayList<PCB> q2;
    ArrayList<PCB> q2part2;///// for second time add process
    ArrayList<PCB> allProcesses;//save all to print info
    ArrayList<PCB> allProcessespart2;///save all in this second part in case tried to enter again 
    ArrayList<String> scheduleOrder; /////the order 
    FileWriter fileWriter;
    
    

    
    //constructor
    public OperatingSystemProject() {
        q1 = new ArrayList<>();
        q1part2 = new ArrayList<>();/////
        q2 = new ArrayList<>();
        q2part2 = new ArrayList<>();////
        allProcesses=new ArrayList<>();/////
        scheduleOrder = new ArrayList<>(); //////
        allProcessespart2=new ArrayList<>();//
        try {
            fileWriter = new FileWriter("Report.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }//constructor

    
    
    
    //add process 
    public void addProcess(PCB process) {
        if (process.priority == 1) {
            q1.add(process);
            q1part2.add(process);
          
        } else if(process.priority == 2) {
            q2.add(process);
            q2part2.add(process);
           
        }else{//in case user enter wrong choice not aviable 
            System.out.println("Invalid choice");
            System.exit(0);
        }
        allProcesses.add(process);
        allProcessespart2.add(process);
    }//add process
    
    
    
    
    
    
    //schedule method for multilevel 
        public void schedule() {
             scheduleOrder.clear(); //in case enter again
 
             
      
        //what time now to use 
        int currentTime = 0;
        
        
        /////////////////////////////////////////////Round Robin//////////////////////////////////////////////////////////////////////////////////

        // Round-robin scheduling for processes in q1
         q1.sort(Comparator.comparingInt(PCB::getArrivalTime));//we are sorting it from small to big y3ni arrive first so if process arrive first do it first
        while (!q1.isEmpty()) {
           
            PCB currentProcess = q1.remove(0); // Remove the first process in q1
            if(currentTime<currentProcess.arrivalTime){
                 //compare we take second arrived if arrivakl time didnt happen yet return and sort again in case p1 still have cpu left
                //it start however if it finish its okay it will sort according to time so 3ady 
                q1.add(currentProcess);
                q1.sort(Comparator.comparingInt(PCB::getArrivalTime));//we are sorting it from small to big y3ni arrive first so if process arrive first do it first
                currentProcess=q1.remove(0);
            }//if it arrive bef time
            
            
          
            if (currentTime < currentProcess.arrivalTime) {
                currentTime = currentProcess.arrivalTime;
            }
            
            
            //in case cpu is 3 or less so wont tnter again and since it wont enter again termination is 0 cuz mara wa7da
            if(currentProcess.cpuBurst<=3 && currentProcess.terminationTime==0){
                currentProcess.startTime = currentTime;
                currentProcess.responseTime = currentProcess.startTime - currentProcess.arrivalTime;
                currentProcess.waitingTime= currentProcess.startTime - currentProcess.arrivalTime;
                currentProcess.terminationTime= currentTime+ currentProcess.cpuBurst;
                currentProcess.turnaroundTime=currentProcess.terminationTime-currentProcess.arrivalTime;
                            // Update the current time
                             currentTime = currentProcess.terminationTime;
                             scheduleOrder.add(currentProcess.pid);
                             continue;//it finish go next iteration
            }//less than 3 cpu or equal 3 enter once 
            
            
            
            if(currentProcess.cpuBurst>3 && currentProcess.terminationTime==0){  //the reason we put temination 0 for the first time it enter
                currentProcess.startTime = currentTime;
                currentProcess.responseTime = currentProcess.startTime - currentProcess.arrivalTime;
                currentProcess.waitingTime= currentProcess.startTime - currentProcess.arrivalTime; //first one 
                currentProcess.terminationTime= currentTime+ 3; // since greater than 3 and quantem is 3 and enter this if statment once
                //calculate turnaround later jame3 waiting first 
            }
            
            // Determine the time slice for the current process
            int timeSlice = Math.min(currentProcess.remainingCpuBurst, 3); // Quantum time of 3 ms this method take smallest between 2
            if(currentProcess.terminationTime!=0)
            currentProcess.terminationTime = currentTime + timeSlice;


            // Update remaining burst time for the process
            currentProcess.remainingCpuBurst -= timeSlice;//minus 3 see how much cpu left

            // If the process still has burst time left, put it back into q1
            if (currentProcess.remainingCpuBurst > 0) {
                q1.add(currentProcess);
            } else { // If the process is finished, calculate turnaround and waiting times
               currentProcess.turnaroundTime=currentProcess.terminationTime-currentProcess.arrivalTime;
               currentProcess.waitingTime=currentProcess.turnaroundTime-currentProcess.cpuBurst;
            }

            // Update the current time
            currentTime = currentProcess.terminationTime;
           //add order 
            scheduleOrder.add(currentProcess.pid);
            
        }//roundrobin 
        q1.addAll(q1part2);///add again to use later 
    /////////////////////////////////////////////////////////Finish round robin/////////////////////////////////////////////////////////////////////////
    
    
    
    
        
   ////////////////////////////////////////////////////////////Shortest job first///////////////////////////////////////////////////////////////////////
         q2.sort(Comparator.comparingInt(PCB::getArrivalTime));
         while(!q2.isEmpty()){

          PCB currentProcess=q2.remove(0);
         if(currentTime>currentProcess.arrivalTime){//need to be 3aks comparison because when arrival is less than timer i enter so i arrange by cpu bec i already arrive
           q2.add(currentProcess);//add process again for comparison
           q2.sort(Comparator.comparingInt(PCB::getCpuBurst));//sort by cpu
           currentProcess=q2.remove(0);//remove lel first one
           while(currentTime<currentProcess.arrivalTime){//if i arrange cpu and for example a process didnt arrive yet i make loop to put who arrive first no order i  mean wesel zaman yeshta8el
               q2.add(currentProcess);
               q2.sort(Comparator.comparingInt(PCB::getArrivalTime));
               currentProcess=q2.remove(0);
           }//loop
       }//if
       
       

        //for (PCB process : q2) 
        {
            if (currentTime < currentProcess.arrivalTime) 
                currentTime = currentProcess.arrivalTime;
            
            currentProcess.startTime = currentTime;
            currentProcess.responseTime = currentTime - currentProcess.arrivalTime;
            currentProcess.terminationTime = currentTime + currentProcess.cpuBurst;
            currentProcess.turnaroundTime = currentProcess.terminationTime - currentProcess.arrivalTime;
            currentProcess.waitingTime = currentProcess.turnaroundTime - currentProcess.cpuBurst;

            // Update the current time
            currentTime = currentProcess.terminationTime;     
            scheduleOrder.add(currentProcess.pid);//add to order
        }

   }//loop  
   q2.addAll(q2part2);//add again if use if add again user 
//////////////////////////////////////////////Finish shortest/////////////////////////////////////////////////////////////////    




        // Write scheduling information to file
        try {
            FileWriter fileWriter = new FileWriter("Report.txt");
            fileWriter.write("Scheduling order: " + scheduleOrder.toString() + "\n");
            //print
            System.out.println("Scheduling order: " + scheduleOrder.toString() + "\n");
            for (PCB process : allProcesses) {
                fileWriter.write("Process ID: " + process.pid + "\n");
                fileWriter.write("Priority: " + process.priority + "\n");
                fileWriter.write("Arrival Time: " + process.arrivalTime + "\n");
                fileWriter.write("CPU Burst: " + process.cpuBurst + "\n");
                fileWriter.write("Start Time: " + process.startTime + "\n");
                fileWriter.write("Termination Time: " + process.terminationTime + "\n");
                fileWriter.write("Turnaround Time: " + process.turnaroundTime + "\n");
                fileWriter.write("Waiting Time: " + process.waitingTime + "\n");
                fileWriter.write("Response Time: " + process.responseTime + "\n\n");
                
                ////print in consolve
                System.out.println("Process ID: " + process.pid + "\n");
                System.out.println("Priority: " + process.priority + "\n");
                System.out.println("Arrival Time: " + process.arrivalTime + "\n");
                System.out.println("CPU Burst: " + process.cpuBurst + "\n");
                System.out.println("Start Time: " + process.startTime + "\n");
                System.out.println("Termination Time: " + process.terminationTime + "\n");
                System.out.println("Turnaround Time: " + process.turnaroundTime + "\n");
                System.out.println("Waiting Time: " + process.waitingTime + "\n");
                System.out.println("Response Time: " + process.responseTime + "\n\n");
            }
            
            double avgTurnaroundTime = allProcesses.stream().mapToInt(p -> p.turnaroundTime).average().orElse(0);//average eq
            double avgWaitingTime = allProcesses.stream().mapToInt(p -> p.waitingTime).average().orElse(0);//average eq
            double avgResponseTime = allProcesses.stream().mapToInt(p -> p.responseTime).average().orElse(0);//average eq
            fileWriter.write("Average Turnaround Time: " + avgTurnaroundTime + "\n");
            fileWriter.write("Average Waiting Time: " + avgWaitingTime + "\n");
            fileWriter.write("Average Response Time: " + avgResponseTime + "\n");
            
            //print cosole
            System.out.println("Average Turnaround Time: " + avgTurnaroundTime + "\n");
            System.out.println("Average Waiting Time: " + avgWaitingTime + "\n");
            System.out.println("Average Response Time: " + avgResponseTime + "\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
         allProcesses.clear(); //clear and readd to work adding again
         allProcesses.addAll(allProcessespart2);//////////////add again same idea up
          
    }//
    
    
   
    
    
    
    
    /*******************************************************MAIN*********************************************************************/
    public static void main(String[] args) {
   Scanner scanner = new Scanner(System.in);
        OperatingSystemProject scheduler = new OperatingSystemProject();
        int numid=1;//for id in case user enters a second time it continue not stop

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Add processes");
            System.out.println("2. Display scheduling information and criteria");
            System.out.println("3. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter the number of processes:");
                    int numProcesses = scanner.nextInt();
                    for (int i = 1; i <= numProcesses; i++) { //i for number of currect process ask 
                        System.out.println("Enter details for process " + numid + ":");
                      
                        System.out.print("Priority: ");
                        int priority = scanner.nextInt();
                        System.out.print("Arrival Time: ");
                        int arrivalTime = scanner.nextInt();
                        System.out.print("CPU Burst Time: ");
                        int cpuBurst = scanner.nextInt();
                        PCB process = new PCB("P" + numid, priority, arrivalTime, cpuBurst);
                        scheduler.addProcess(process);
                        numid++;//increment after add
                    }
                    break;
                case 2:
                    scheduler.schedule();
                    System.out.println("Scheduling information written to Report.txt");
                    break;
                case 3:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    
}
